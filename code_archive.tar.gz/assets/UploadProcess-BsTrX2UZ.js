import{j as s}from"./index-Bkm8xyUv.js";const r=()=>s.jsx("div",{children:"UploadProcess"});export{r as default};

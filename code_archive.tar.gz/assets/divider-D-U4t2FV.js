import{j as r}from"./index-Bkm8xyUv.js";const i=({show:s})=>r.jsx("div",{className:`${s?"block":"hidden"} w-full h-[1px] bg-[#FFFFFF0A]`});export{i as D};

import{j as s}from"./index-BFSzmr0H.js";const r=()=>s.jsx("div",{children:"UploadProcess"});export{r as default};

import{j as r}from"./index-BFSzmr0H.js";const t=()=>r.jsx("div",{});export{t as default};

import{j as r}from"./index-Bkm8xyUv.js";const t=()=>r.jsx("div",{});export{t as default};
